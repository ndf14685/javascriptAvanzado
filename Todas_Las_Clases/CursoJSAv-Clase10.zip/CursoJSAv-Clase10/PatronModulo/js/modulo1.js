console.log('Clase 10 Javascript Avanzado! -> Patrón Módulo ');

/*
// ---------------
//  PATRÓN MÓDULO
// ---------------
El patrón módulo es la implementación o uso constante de funciones anónimas autoinvocadas (IIFE) con todo nuestro código (variables y funciones) adentro
Por qué????
- Dentro de nuestor módulo podemos restringir ó controlar el acceso a las variables o funciones
- Nadie puede tocarnos o romper nuestros datos o funciones
- No permito que nadie acceda a lo que NO publico
- Logro un encapsulamiento => funciones y variables críticas quedan privadas de la función autoinvocada (no se pueden acceder)
*/
(function() {
    var x = 3.1415927;
    function getX() {
        console.log(x);
    }
    window.modulo1 = getX;
    console.log('OK IIFE 1');
})()
