(function(){
    var y = 1;

    function changeY(val) {
        y = val;
        console.log(y);
    }
    window.modulo2 = changeY;
    console.log('OK IIFE 2');

})();