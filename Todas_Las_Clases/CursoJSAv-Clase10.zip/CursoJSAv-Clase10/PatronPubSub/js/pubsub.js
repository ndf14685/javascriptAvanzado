console.log('Clase 10 JSAv - Patrón PubSub');

/*
PATRÓN PUBLICACIÓN/SUBSCRIPCIÓN (Pub/Sub)
La idea es poder disponer de un mecanismo de débil acoplamiento ó acoplamiento flexible entre objetos vinculados
*/

// -----------------------------------------------------
// Ejemplo de acoplamiento NO flexible entre dos objetos
// -----------------------------------------------------
/*
var Orden = function(mail) {
    this.mail = mail;
}
Orden.prototype = {
    enviar: function() {
        console.log('Orden guardada');
        this.enviarMail();
    },
    enviarMail: function() {
      var mailer = new Mailer();
      mailer.enviarMailDeCompra(this.mail);
    }
}


var Mailer = function() {};
Mailer.prototype = {
    enviarMailDeCompra: function(mail) {
        console.log('Email enviado a ' + mail.mailDestino);
    }
}

var orden = new Orden({ mailDestino : 'daniel@hotmail.com'});
orden.enviar();
*/

// ---------------------------------------------------------------------------------
// Ejemplo de acoplamiento flexible entre dos objetos (Utilizando el Patrón Pub/Sub)
// ---------------------------------------------------------------------------------
var BusComunicacion = {
    acciones : {},

    suscribir: function(accion, callback) {
        if(!this.acciones[accion]) this.acciones[accion] = [];

        this.acciones[accion].push(callback);
    },

    publicar: function( accion, datos) {
        if(!this.acciones[accion] || this.acciones[accion].length < 1) {
            return;
        }
        
        this.acciones[accion].forEach(function(cb) {
            cb(datos || {});
        });
    }
}

/*
BusComunicacion.suscribir('daniel', alert);
console.log('Daniel SUBSCRIPTO!!!!!!');
setTimeout(() => {
    BusComunicacion.publicar('daniel', 'Llegó el Diario!!!!!!!!');
},5000);
*/

//-------------
//Objeto MAILER
//-------------
var Mailer = function() {
    BusComunicacion.suscribir('orden', this.enviarMailDeCompra);
}
Mailer.prototype = {
    enviarMailDeCompra : function(mail) {
        console.log('Email enviado a ' + mail);
    }
}

//-------------
//Objeto Orden
//-------------
var Orden = function(mail) {
    this.mail = mail;
}
Orden.prototype = {
    guardarOrden : function() {
        BusComunicacion.publicar('orden', this.mail.mailDestino);
    }
};

var mailer = new Mailer();
var orden = new Orden({ mailDestino : 'daniel@hotmail.com'});
console.log('Mailer Susbcripto!!!');
//orden.guardarOrden();
setTimeout(() => {
    orden.guardarOrden();
},5000);









