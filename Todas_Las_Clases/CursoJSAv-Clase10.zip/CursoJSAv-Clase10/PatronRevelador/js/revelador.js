console.log('Clase 10 JSAv - Patrón Revelador');

/*
// -----------------
// PATRÓN REVELADOR
// -----------------
Persigue el mismo que el Patrón Módulo, pero expresado de forma distintas (más moderna y funcional)
*/

var modulo = (function(){
    var x = 'Hola!';
    return function() {
        console.log(x);
    }
})();