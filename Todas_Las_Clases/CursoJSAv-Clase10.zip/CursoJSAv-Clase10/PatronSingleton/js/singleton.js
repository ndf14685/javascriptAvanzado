console.log('Clase 10 JSAv - Patrón Singleton');

/*
// ----------------------
// PATRÓN SINGLETON
// ----------------------
Obtiene una única instancia de la clase que vamos a definir.
No vamos a poder instanciar multiples clases.
Para qué???
Por ej. el objeto History del navegador -> nos controla el historial de navegación, necesitamos tener una sóla copia del objeto history
En alguna parte del programa se hizo un new History, que creo la primera y única instancia.

Sería peligroso tener dos veces el historial de un cliente o generar un historial nuevo

Para resolver este inconveniente utilizamos el Patrón Singleton

Como lo implementamos?????
*/

(function(){

    let instancia; //undefined

    function App() {
        //mensajes - historial - usuarios - etc
        //this = {} -> new
        if(instancia != undefined) {
            return instancia;
        }
        else {
            this.id = Math.random();
            instancia = this;
        }
        //return this -> new
    }
    window.app = App;
    console.log('Función IIFE Ok!');

    /*
    var a = new App();
    var b = new App();
    */
})();




