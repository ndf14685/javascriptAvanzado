let mensaje = 'Bienvenidos a NodeJS';
console.log(mensaje);

function sumar(a,b) {
    return a + b;
}

let cuadradoDe = a => a*a;

console.log('La suma es', sumar(5,6));
const numero = 8;
console.log(`El cuadrado de ${numero} es ${cuadradoDe(numero)}`);

