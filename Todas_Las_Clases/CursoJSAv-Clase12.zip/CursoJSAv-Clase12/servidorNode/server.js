const PORT = 8080;
//-------------------------------------------------------------------------
require('http').createServer((req,res) => res.end(`<p>Servidor: ${PORT+1} ${new Date()}</p>`)).listen( PORT+1, err => { if(!err) console.log(`Ok ${PORT+1}`)} );
require('http').createServer((req,res) => res.end(`<p>Servidor: ${PORT+2} ${new Date()}</p>`)).listen( PORT+2, err => { if(!err) console.log(`Ok ${PORT+2}`)} );
require('http').createServer((req,res) => res.end(`<p>Servidor: ${PORT+3} ${new Date()}</p>`)).listen( PORT+3, err => { if(!err) console.log(`Ok ${PORT+3}`)} );
require('http').createServer((req,res) => res.end(`<p>Servidor: ${PORT+4} ${new Date()}</p>`)).listen( PORT+4, err => { if(!err) console.log(`Ok ${PORT+4}`)} );
//-------------------------------------------------------------------------

const http = require('http');


let contador = 0;


let getFechaHora = () => `
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>Documento Web</title>
        </head>
        <body style="background-color: cyan; color:blue;">
            
            <h1>Página web desde nodeJS</h1>
            <h2 style="color: #333;">La fecha y hora actual es: ${new Date()}</h2>
            <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Accusantium sunt veniam ullam nihil labore beatae, doloremque officiis dolor vero rem animi repudiandae voluptates sit, rerum optio? Incidunt, nobis animi! Voluptatem.
            </p>

        </body>
        </html>
    `

const getDatosCb = cb => {
    setTimeout( () => cb(), 3000);
}

const getDatosPromise = () => new Promise((resolve, reject) => {
    setTimeout( () => resolve(), 15000);
})


http.createServer((req,res) => {
    let url = req.url;
    //console.log(url);
    if(url == '/') {
        console.log(contador++);
    }

    //getDatosCb( () => {
    getDatosPromise()
    .then( () => {
        res.writeHead(200, {'Content-type':'text/html'});
        res.write(getFechaHora());
        //res.write('<h1>Hola Mundo desde NodeJS!!!: '+ new Date()+'</h1>');
        res.end();
    });

}).listen(PORT);

console.log(`Servidor escuchando en el puerto ${PORT}`);

