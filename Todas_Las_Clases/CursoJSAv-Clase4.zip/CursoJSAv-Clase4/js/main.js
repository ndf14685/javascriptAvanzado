console.log('Clase 4 JSAv');


let btn = document.querySelector('button');
btn.addEventListener('click', () => {

    // ----------------------
    // Api Web XMLHttpRequest
    // ----------------------
    //XHR - Ajax
    let xhr = new XMLHttpRequest();
    //readyState
    //0 - instacia está creada
    //1 - ya está configurado
    //2 - ya la información fue enviada y los header fueron recibidos
    //3 - descargando
    //4 - la transferencia ha finalizado, no necesariamente en forma exitosa
    console.log(xhr.readyState);
    //get - post - put - delete
    xhr.open('get', 'plantilla.html');
    //xhr.open('get','texto.txt');
    console.log(xhr.readyState);

    xhr.addEventListener('readystatechange', () => {
        console.log(xhr.readyState);

        if (xhr.readyState == 2) {
            let header = xhr.getAllResponseHeaders();
            //console.log(header);
            let tipo = xhr.getResponseHeader('content-type');
            let lng = xhr.getResponseHeader('content-length');
            console.log('tipo', tipo);
            console.log('length', lng);
            if (tipo != 'text/html') {
                //xhr.abort();
            }
        }
        else if (xhr.readyState == 4) {
/*         if(xhr.status == 200) {
            console.log(xhr.response);
        }
        else if(xhr.status == 404) {
            console.log('ERROR!!!!');
            console.log(xhr.status);
            console.log(xhr.statusText);
            console.log(xhr.responseURL);
        }
        else {
            console.log('ERROR en status', xhr.status);
        }
 */    }
    })

    xhr.addEventListener('load', () => {
        if (xhr.status == 200) {
            console.log(xhr.response);
            let planilla = xhr.response;
            let div = document.createElement('div');
            div.innerHTML = planilla;
            document.body.appendChild(div);
        }
        else if (xhr.status == 404) {
            console.log('ERROR!!!!');
            console.log(xhr.status);
            console.log(xhr.statusText);
            console.log(xhr.responseURL);
        }
        else {
            console.log('ERROR en status', xhr.status);
        }
    })

    xhr.addEventListener('timeout', () => {
        console.log('El pedido se ha excedido de tiempo');
    })

    //xhr.timeout = 1;
    xhr.send();
    /*
    setTimeout(()=>{
        console.log(xhr.response);
    },3000);
    */
})


/*
// ----------------------
// Http
// ----------------------
//tamaño del recurso solicitado en bytes
content-length: 33507
//tipo de recurso que pedido o recibimos
content-type: text/javascript; charset=UTF-8

// ----------------------
// Javascript Asincrónico
// ----------------------
//asincronismo
setTimeout(()=>{
    console.log('Timeout!!!');
}, 2000);
console.log('ya ejecuté setTimeout');

//sincronismo
console.log(1);
console.log(2);
console.log(3);
console.log(4);
*/
