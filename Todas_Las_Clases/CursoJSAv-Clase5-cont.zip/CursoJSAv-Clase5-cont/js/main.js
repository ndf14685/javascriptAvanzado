console.log('Clase 5 JSAv');

/*
SPA Pagina del tipo Single Page Application
Navegación es sintética, construida, artificial
El usuario tenga la sensación de que esta navegando por distintos contenidos, pero sin recarga completa del documento. Para eso vamos a estar inyectando de manera asincrónica ese contenido (Ajax - xhr - XMLHttpResquest).
*/

function ajax(url, metodo) {
    let http_metodo = metodo || 'get';
    let xhr = new XMLHttpRequest();
    xhr.open(http_metodo, url);
    xhr.send();

    return xhr;
}


/*
El problema de la navegación en SPA
SPA -> ventaja -> no recarga contenido -> inyectando pequeños fragmentos de HTML de manera dinámica, sin actualizar completamente la página
SPA -> desventaja -> navegación ficticia -> si vuelvo para atrás -> no me respeta la navegación -> la URL no corresponde

Para resolver el problema, necesitamos manejar el HISTORIAL de NAVEGACIÓN "a mano", tenemos que controlar la API de 'History' -> se encuentra en el navegador.

*/
/*
// ------------------------------------------------
// CONTROL DE LA NAVEGACIÓN DEL SITIO USANDO HASH #
// ------------------------------------------------
let main = document.querySelector('main');
let links = document.querySelectorAll('a');

links.forEach( link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        let id = link.id;
        location.hash = id;
        //console.log(id);
    })
})

let archivo = location.hash.split('#')[1] + '.html';
let pagina_inicial = ajax(archivo);
pagina_inicial.addEventListener('load', () => {
    if(pagina_inicial.status == 200) {
        main.innerHTML = pagina_inicial.response;
    }
})

window.addEventListener('hashchange',()=> {
    console.log('cambió la URL');
    //console.log(location.hash);

    let archivo = location.hash.split('#')[1] + '.html';
    //console.log(archivo);
    let xhr = ajax(archivo);
    xhr.addEventListener('load',()=>{
        if(xhr.status == 200) {
            //console.log('respuesta OK!',xhr.response);
            main.innerHTML = xhr.response;
        }
    })
})
*/

/*
// ---------------------------------------------------
// CONTROL DE LA NAVEGACIÓN DEL SITIO USANDO PUSHSTATE
// ---------------------------------------------------
let main = document.querySelector('main');
let links = document.querySelectorAll('a');

links.forEach( link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        let id = link.id;
        console.log('1',id);
        history.pushState(null,'',id);

        let archivo = id + '.html'
        let xhr = ajax(archivo);
        xhr.addEventListener('load', ()=> {
            if(xhr.status == 200) {
                main.innerHTML = xhr.response;
            }
        })
    })
})

let archivo = 'home.html';
let pagina_inicial = ajax(archivo);
pagina_inicial.addEventListener('load', () => {
    if(pagina_inicial.status == 200) {
        main.innerHTML = pagina_inicial.response;
    }
})


window.addEventListener('popstate',()=> {
    console.log('cambió el historial');

    let partes = location.pathname.split('/');
    console.log('partes',partes);
    if(partes.length == 2 && partes[1].length) {
    
        let archivo = (partes[1]=='index.html'? 'home' : partes[1]) + '.html';
        console.log('2',archivo);

        let xhr = ajax(archivo);
        xhr.addEventListener('load', ()=> {
            if(xhr.status == 200) {
                main.innerHTML = xhr.response;
            }
        })
    }
})
*/
/*
// -----------------------------------------------------------
// CONTROL DE LA NAVEGACIÓN DEL SITIO USANDO PUSHSTATE (CACHE)
// -----------------------------------------------------------
let main = document.querySelector('main');
let links = document.querySelectorAll('a');

links.forEach( link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        let id = link.id;
        console.log('1',id);

        let archivo = id + '.html'
        let xhr = ajax(archivo);
        xhr.addEventListener('load', ()=> {
            if(xhr.status == 200) {
                history.pushState({
                    template : xhr.response
                },'',id);
                main.innerHTML = xhr.response;
            }
        })
    })
})

let archivo = 'home.html';
let pagina_inicial = ajax(archivo);
pagina_inicial.addEventListener('load', () => {
    if(pagina_inicial.status == 200) {
        main.innerHTML = pagina_inicial.response;
    }
})


window.addEventListener('popstate',(e)=> {
    console.log('cambió el historial');
    console.log(e.state);
   
    if(e.state.template) {
        main.innerHTML = e.state.template;
    }
    else {
        let partes = location.pathname.split('/');
        console.log('partes',partes);
        if(partes.length == 2 && partes[1].length) {
        
            let archivo = (partes[1]=='index.html'? 'home' : partes[1]) + '.html';
            console.log('2',archivo);

            let xhr = ajax(archivo);
            xhr.addEventListener('load', ()=> {
                if(xhr.status == 200) {
                    main.innerHTML = xhr.response;
                }
            })
        }
    }
})
*/
/*
// ------------------------------------------
// CONSUMO DE RECURSOS EXTERNOS MEDIANTE AJAX
// ------------------------------------------
let xhr = new XMLHttpRequest();
xhr.open('get', 'https://jsonplaceholder.typicode.com/users');
xhr.addEventListener('load', ()=> {
    if(xhr.status == 200) {
        console.log(typeof xhr.response);
        let respuesta = JSON.parse(xhr.response);
        console.log(respuesta);
    }
})
xhr.send();
*/

// ------------------------------------
// CORS - Cross Origin Resource Sharing
// ------------------------------------
//Politica de autorización que nos posibilita acceso a datos /de servidores que no nos pertenecen se gestiona a través de Headers de autorización

//access-control-allow-origin : cabecera de seguridad para pedidos ajax externos
//access-control-allow-origin -> quien tiene acceso?
//access-control-allow-origin : localhost
//access-control-allow-origin : * -> todos

/*
// --------------------------------------------------
// CONSUMO DE RECURSOS EXTERNOS MEDIANTE AJAX (ERROR)
// --------------------------------------------------
let url = 'https://en.wikipedia.org/w/api.php?action=query&meta=siteinfo&siprop=namespaces&format=json';
let xhr = new XMLHttpRequest();
xhr.open('get', url);
xhr.addEventListener('load', ()=> {
    if(xhr.status == 200) {
        console.log(typeof xhr.response);
        let respuesta = JSON.parse(xhr.response);
        console.log(respuesta);
    }
})
xhr.send();
*/

// --------------------------------------------------
// CONSUMO DE RECURSOS EXTERNOS MEDIANTE AJAX (JSONP)
// --------------------------------------------------
//'https://en.wikipedia.org/w/api.php?action=query&meta=siteinfo&siprop=namespaces&format=json&callback=micallback';

let url = 'https://en.wikipedia.org/w/api.php?action=query&meta=siteinfo&siprop=namespaces&format=json';

let xhr = new XMLHttpRequest();
xhr.open('get', url);
xhr.addEventListener('load', ()=> {
    if(xhr.status == 200) {
        console.log(typeof xhr.response);
        let respuesta = JSON.parse(xhr.response);
    }
})
xhr.send();


xhr.addEventListener('error', ()=>{
    console.log('xhr.addEventListener(error)');
    let script =document.createElement('script');
    script.src = `${url}&callback=micallback`;
    document.body.appendChild(script);
})

function micallback(respuesta) {
    console.log(respuesta);
}
