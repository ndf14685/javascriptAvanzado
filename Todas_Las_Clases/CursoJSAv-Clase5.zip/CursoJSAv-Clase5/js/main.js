console.log('Clase 5 JSAv');

/*
SPA Pagina del tipo Single Page Application
Navegación es sintética, construida, artificial
El usuario tenga la sensación de que esta navegando por distintos contenidos, pero sin recarga completa del documento. Para eso vamos a estar inyectando de manera asincrónica ese contenido (Ajax - xhr - XMLHttpResquest).
*/

function ajax(url, metodo) {
    let http_metodo = metodo || 'get';
    let xhr = new XMLHttpRequest();
    xhr.open(http_metodo, url);
    xhr.send();

    return xhr;
}


/*
El problema de la navegación en SPA
SPA -> ventaja -> no recarga contenido -> inyectando pequeños fragmentos de HTML de manera dinámica, sin actualizar completamente la página
SPA -> desventaja -> navegación ficticia -> si vuelvo para atrás -> no me respeta la navegación -> la URL no corresponde

Para resolver el problema, necesitamos manejar el HISTORIAL de NAVEGACIÓN "a mano", tenemos que controlar la API de 'History' -> se encuentra en el navegador.

*/

/*
// ------------------------------------------------
// CONTROL DE LA NAVEGACIÓN DEL SITIO USANDO HASH #
// ------------------------------------------------
let main = document.querySelector('main');
let links = document.querySelectorAll('a');

links.forEach( link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        let id = link.id;
        location.hash = id;
        //console.log(id);
    })
})

let pagina_inicial = ajax('home.html');
pagina_inicial.addEventListener('load', () => {
    if(pagina_inicial.status == 200) {
        main.innerHTML = pagina_inicial.response;
    }
})

window.addEventListener('hashchange',()=> {
    //console.log('cambió la URL');
    //console.log(location.hash);

    let archivo = location.hash.split('#')[1] + '.html';
    //console.log(archivo);
    let xhr = ajax(archivo);
    xhr.addEventListener('load',()=>{
        if(xhr.status == 200) {
            //console.log('respuesta OK!',xhr.response);
            main.innerHTML = xhr.response;
        }
    })
})

// ---------------------------------------------------
// CONTROL DE LA NAVEGACIÓN DEL SITIO USANDO PUSHSTATE
// ---------------------------------------------------
let main = document.querySelector('main');
let links = document.querySelectorAll('a');

links.forEach( link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        let id = link.id;
        history.pushState(null,'',id);
        //console.log(location.pathname.split('/')[1]);
        //console.log(id);
        //let archivo = id + '.html';
        let archivo = location.pathname.split('/')[1] + '.html';
        let xhr = ajax(archivo);
        xhr.addEventListener('load', ()=> {
            if(xhr.status == 200) {
                history.pushState({
                    template: xhr.response
                },'',id);
                main.innerHTML = xhr.response;
            }
        })
    })
})

let pagina_inicial = ajax('home.html');
pagina_inicial.addEventListener('load', () => {
    if(pagina_inicial.status == 200) {
        main.innerHTML = pagina_inicial.response;
    }
})
*/

/*
// ------------------------------------------
// CONSUMO DE RECURSOS EXTERNOS MEDIANTE AJAX
// ------------------------------------------
console.log('ajax externo');
let xhr = new XMLHttpRequest();
xhr.open('get', 'https://jsonplaceholder.typicode.com/users');
xhr.addEventListener('load', ()=> {
    if(xhr.status == 200) {
        console.log(typeof xhr.response);
        let respuesta = JSON.parse(xhr.response);
        console.log(respuesta);
    }
})
xhr.send();
*/

// ------------------------------------
// CORS - Cross Origin Resource Sharing
// ------------------------------------
//Politica de autorización que nos posibilita acceso a datos /de servidores que no nos pertenecen se gestiona a través de Headers de autorización

//access-control-allow-origin : cabecera de seguridad para pedidos ajax externos
//access-control-allow-origin -> quien tiene acceso?
//access-control-allow-origin : localhost
//access-control-allow-origin : * -> todos

//https://es.glosbe.com/a-api
let url = 'https://glosbe.com/gapi/translate?from=es&dest=en&phrase=hola&format=json';

let xhr = new XMLHttpRequest();
xhr.open('get', 'https://jsonplaceholder.typicode.com/users');
xhr.addEventListener('load', ()=> {
    if(xhr.status == 200) {
        console.log(typeof xhr.response);
        let respuesta = JSON.parse(xhr.response);
        console.log(respuesta);
    }
})
xhr.send();

