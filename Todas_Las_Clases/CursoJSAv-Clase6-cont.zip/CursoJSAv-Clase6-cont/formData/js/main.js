console.log('Clase 7 JSAv');

/*
FormData -> Juntar la info que queremos enviar a un servidor

Trabaja de dos formas
    1) Recolectando información que se encuentra en un formulario
    2) Entrando la información en forma manual
*/

/*
// ----------------- 1) -------------------
let form = document.querySelector('form');
form.addEventListener('submit', (e) => {
    e.preventDefault();

    let data = new FormData(form);
    console.log(data);
    let valores = data.values();
    console.log(valores);

    console.log(valores.next().value);
    console.log(valores.next().value);

})
// ----------------------------------------

// ----------------- 2) -------------------
let btn = document.querySelector('button');

let data;
let valores;
btn.addEventListener('click', () => {
    data = new FormData();
    for (let i = 0; i < 10; i++) {
        data.append(`param-${i}`, i);
    }
    valores = data.values();

    let datos;
    //     for (let i = 0; i < 20; i++) {
    for( ; ; ) {
        datos = valores.next();
        if (datos.done) break;
        console.log(datos.value);
    }
    console.log('-------')
})
// ----------------------------------------
*/

// --------------------------------------------------------
//Envío por método POST de datos del usuario utilizando xhr
/*
let xhr = new XMLHttpRequest();
xhr.open('POST','url');
//xhr.setRequestHeader('content-type','?');
xhr.send( '--INFO A TRANSMITIR--' );
*/
//Con FormData podemos aprovechar el formato de sus datos y enviamos de esta forma:
let data = new FormData();
for (let i = 0; i < 10; i++) {
    data.append(`Imagen-${i}`, i);
}
xhr = new XMLHttpRequest();
xhr.open('POST','url');
xhr.send(data);









