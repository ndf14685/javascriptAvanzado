console.log('Clase 6 - JSAv');

let xhr;

let form = document.querySelector('form');
let progress = document.querySelector('progress');
let textoProgreso = document.querySelector('#texto-progreso');

form.addEventListener('submit', e => {
    e.preventDefault();
    let url = form[0].files[0].name;//'imagen.jpg';
    //console.log(url);

    xhr = new XMLHttpRequest();
    xhr.responseType = 'blob';
    xhr.open('get',url + '?' + Date.now());
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            let imagen_blob = xhr.response;
            let url_blob = URL.createObjectURL(imagen_blob);
            //console.log(url_blob);

            let img = document.createElement('img');
            img.src = url_blob;
            document.body.appendChild(img);
        }
    })

    xhr.addEventListener('progress', e => {
        //console.log('Descargando...');
        //console.log(e);
        if(e.lengthComputable) {
            let porcentaje = parseInt((e.loaded * 100) / e.total);
            console.log(porcentaje);
            progress.value = porcentaje;
            /*            
            let p = document.createElement('p');
            p.innerText = 'recibido: ' + porcentaje + '%';
            document.body.appendChild(p);
            */
            textoProgreso.innerText = ' ' + porcentaje + '%';
        }
    })

    xhr.send();
})






