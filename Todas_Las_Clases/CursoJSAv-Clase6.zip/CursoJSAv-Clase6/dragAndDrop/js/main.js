console.log('Drag and Drop en JS');

/*
Eventos de DRAG and DROP
1) dragenter -> se dispara cuando entramos a una zona de d&d
2) dragleave -> se dispara cuando salimos de una zona d&d
3) dragover -> se llama cuando permanecemos en la zona d&d
4) drop -> se llama cuando soltamos una recurso dentro de la zona d&d
*/

let drop = document.getElementById('drop');
let input = document.querySelector('input');

function manejarArchivos(archivos) {
    console.log(archivos);

    //xhr
}

input.addEventListener('change', () => {
    //console.log('Cambió el contenido de input');
    manejarArchivos(input.files[0].name);
})

drop.addEventListener('dragenter', e => {
    e.preventDefault();
    console.log('entré a la zona d&d');
})

drop.addEventListener('dragleave', e => {
    e.preventDefault();
    console.log('salí de la zona d&d');
})

drop.addEventListener('dragover', e => {
    e.preventDefault();
    console.log('estoy en la zona d&d');
})

drop.addEventListener('drop', e => {
    e.preventDefault();
    console.log('solté el recurso');
    manejarArchivos(e.dataTransfer.files[0].name);
})

