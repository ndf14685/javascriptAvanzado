console.log('CursoJVAv - 7');

// -----------------------------------------------------------------------
// --- FETCH ( XHR + PROMESAS + Response(json, text, formData, blob)) ----
// -----------------------------------------------------------------------

function getPostFetch(url) {
    return fetch(url);
}


getPostFetch('https://jsonplaceholder.typicode.com/posts/1')
.then(response => response.json())
.then(json => {
    console.log(json);
    return getPostFetch('https://jsonplaceholder.typicode.com/posts/2');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return getPostFetch('https://jsonplaceholder.typicode.com/posts/3');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return getPostFetch('https://jsonplaceholder.typicode.com/posts/4');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return getPostFetch('https://jsonplaceholder.typicode.com/posts/5');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return getPostFetch('https://jsonplaceholder.typicode.com/posts/6');
})
.then(response => response.json())
.then(json => {
    console.log(json);
})


/*
fetch('https://jsonplaceholder.typicode.com/posts/1')
.then(response => {
    console.log(response);
    return response.json();
})
.then(json => {
    console.log(json);
    return fetch('https://jsonplaceholder.typicode.com/posts/2');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return fetch('https://jsonplaceholder.typicode.com/posts/3');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return fetch('https://jsonplaceholder.typicode.com/posts/4');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return fetch('https://jsonplaceholder.typicode.com/posts/5');
})
.then(response => response.json())
.then(json => {
    console.log(json);
    return fetch('https://jsonplaceholder.typicode.com/posts/6');
})
.then(response => response.json())
.then(json => {
    console.log(json);
})
*/
// -----------------------------------------------------------------------


/*
// --- PROMESAS (PROMISE) PARA RESOLVER EL PROBLEMA ----
function getPostXHRPromise(url,debug) {
    return new Promise((resolve, reject) => {

        let xhr = new XMLHttpRequest();
        xhr.open('GET',url);
        xhr.addEventListener('load', () => {
            if(xhr.status == 200) {
                let respuesta = JSON.parse(xhr.response);
                if(debug) console.log(respuesta);
                resolve(respuesta);
            }
            else {
                reject(xhr);
            }
        })
        xhr.addEventListener('error',() => {
            reject(xhr);
        })
        xhr.send();
    })
}

getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/1', true)
.then( respuesta => getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/2', true))
.then( respuesta => getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/3', true))
.then( respuesta => getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/4', true))
.then( respuesta => getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/5', true))
.then( respuesta => getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/6', true))
.catch( error => console.log('ERROR', error ) )
*/
/*
getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/1', !true)
.then( respuesta => {
    console.log(respuesta);
    return getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/2', !true)
})
.then( respuesta => {
    console.log(respuesta);
    return getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/3', !true)
})
.then( respuesta => {
    console.log(respuesta);
    return getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/4', !true)
})
.then( respuesta => {
    console.log(respuesta);
    return getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/5', !true)
})
.then( respuesta => {
    console.log(respuesta);
    return getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/6', !true)
})
.then( respuesta => {
    console.log(respuesta);
    return getPostXHRPromise('https://jsonplaceholder.typicode.com/posts/7', !true)
})
.then( respuesta => console.log(respuesta) )
.catch( error => console.log('ERROR', error ) )

console.log('PROGRAMA!!!!');
*/

/*
// --- PIRAMIDE DE LA PERDICIÓN ó INFIERNO DE CALLBACKS----
function getPostXHR(url, debug, cb) {
    let xhr = new XMLHttpRequest();
    xhr.open('GET',url);
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            if(debug) console.log(xhr.response);
            cb(xhr.response);
        }
        else {
            cb('error');
        }
    })
    xhr.send();
}

getPostXHR('https://jsonplaceholder.typicode.com/posts/1', true, (respuesta) => {
    getPostXHR('https://jsonplaceholder.typicode.com/posts/2', true, (respuesta) => {
        getPostXHR('https://jsonplaceholder.typicode.com/posts/3', true, (respuesta) => {
            getPostXHR('https://jsonplaceholder.typicode.com/posts/4', true, (respuesta) => {
                getPostXHR('https://jsonplaceholder.typicode.com/posts/5', true, (respuesta) => {
                    getPostXHR('https://jsonplaceholder.typicode.com/posts/6', true, (respuesta) => {
                        console.log('fin!');
                    })
                })
            })
        })
    })
})



let xhr = new XMLHttpRequest();
xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/1');
xhr.addEventListener('load', () => {
    if (xhr.status == 200) {
        console.log(xhr.response);

        xhr = new XMLHttpRequest();
        xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/2');
        xhr.addEventListener('load', () => {
            if (xhr.status == 200) {
                console.log(xhr.response);

                xhr = new XMLHttpRequest();
                xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/3');
                xhr.addEventListener('load', () => {
                    if (xhr.status == 200) {
                        console.log(xhr.response);

                        xhr = new XMLHttpRequest();
                        xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/4');
                        xhr.addEventListener('load', () => {
                            if (xhr.status == 200) {
                                console.log(xhr.response);

                                xhr = new XMLHttpRequest();
                                xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/5');
                                xhr.addEventListener('load', () => {
                                    if (xhr.status == 200) {
                                        console.log(xhr.response);

                                        xhr = new XMLHttpRequest();
                                        xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/6');
                                        xhr.addEventListener('load', () => {
                                            if (xhr.status == 200) {
                                                console.log(xhr.response);
                                            }
                                        })
                                        xhr.send();
                                    }
                                })
                                xhr.send();
                            }
                        })
                        xhr.send();
                    }
                })
                xhr.send();
            }
        })
        xhr.send();
    }
})
xhr.send();


// --- NO SE DEBE HACER PARA ARREGLAR LA PIRAMIDE DE LA PERDICIÓN ----
let xhr = new XMLHttpRequest();
xhr.open('GET','https://jsonplaceholder.typicode.com/posts/1');
xhr.addEventListener('load', () => {
    if(xhr.status == 200) {
        console.log(xhr.response);
        s2();
    }
})
xhr.send();


function s6() {
    xhr = new XMLHttpRequest();
    xhr.open('GET','https://jsonplaceholder.typicode.com/posts/6');
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            console.log(xhr.response);
        }
    })
    xhr.send();
}

function s5() {
    xhr = new XMLHttpRequest();
    xhr.open('GET','https://jsonplaceholder.typicode.com/posts/5');
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            console.log(xhr.response);
            s6();
        }
    })
    xhr.send();
}

function s4() {
    xhr = new XMLHttpRequest();
    xhr.open('GET','https://jsonplaceholder.typicode.com/posts/4');
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            console.log(xhr.response);
            s5();
        }
    })
    xhr.send();
}


function s3() {
    xhr = new XMLHttpRequest();
    xhr.open('GET','https://jsonplaceholder.typicode.com/posts/3');
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            console.log(xhr.response);
            s4();
        }
    })
    xhr.send();
}

function s2() {
    xhr = new XMLHttpRequest();
    xhr.open('GET','https://jsonplaceholder.typicode.com/posts/2');
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            console.log(xhr.response);
            s3();
        }
    })
    xhr.send();
}
*/

