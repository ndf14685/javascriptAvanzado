console.log('Curso JSav clase 8');

// --------------------------------------------------
// Que es un un prototipo y cuales son las variantes 
// --------------------------------------------------
/*
Prototipo: Conjunto de Normas que nos permiten integrar la orientación a objetos en JS
El prototipo va a ser un objeto
3 formas para contruir un prototipo en JS
    1) Funciones constructoras
    2) Función Create
    3) Forma literal
*/
/*
//3 - Forma literal
let a = {}; //prototipo por default __proto__

//2 - Forma Create
let prototipo = {
    saludo: function() {
        console.log('Hola');
    }
} 

let b = Object.create(prototipo);
*/

// ------------------------------------------------------
// Configuración Avanzada de las propiedades de un objeto
// ------------------------------------------------------

//let a = {x:1};
/*
Las propiedades de un objeto en JS son dinámicas
Podemos leerlas, escribirlas, borrarlas e iterarlas

Para lograr un control más estricto sobre los accesos a las propiedades de un objeto utilizamos la función Create, permite controlar 4 aspectos o propiedades de la configuración de un objeto
    1) value (valor de la propiedad)
    2) writable (determina si una propiedad admite escritura)
    3) enumerable (permite iterar o recorrer los valores o propiedades de un objeto)
    4) configurable (me indica si la propiedad admite el borrado
*/
/*
let b = Object.create(null, {
    x: {
        value: 2,
        writable: false,
        enumerable: false,
        configurable: false
    }
})
*/

// ---------------
// Funciones en JS
// ---------------
/*
Las funciones en JS son similares a las funciones declaradas en otros lenguajes, "excepto" que en JS todo es un objeto => En JS una función es un objeto
*/

//function foo(a,b){
//}

/*
Las funciones en JS son variádicas:
No depender de la cantidad de parámetros definidos ni de la cantidad de argumentos que le pasamos, en otros lenguajes de programación (c,c++,java,c#), si no coinciden => da error!!!
*/
//foo(4)

/*
Las funciones en Js poseen Ambito ó Scope, además se le agrega una propiedad más llamada Contexto
*/

/*
Las funciones son plantillas generadoras de nuevos objetos en JS === clases
*/
//new foo // -> generar un nuevo objeto partiendo de una función constructura


// -------------------------------
// Ambito / Clousure de un función
// -------------------------------
//Ambito ó scope es el alcance que tiene tiene una función para llegar a una variable determinada
/*
var a = 2; //variable global
function foo(c) { //variable preinicializada ó argumento
    var b = 3; //variable local
    console.log(a,b,c);
}

foo(4);
*/
/*
JS además cuenta con un espacio adicional llamado Clousure
*/
/*
function externa(x) {
    //console.log(x);
    //return x;
    return function interna(y) {
        console.log(y+x);
    }
}

var resultado = externa(50);
*/
/*
Como se puede ver, cuando generamos la ejecución de la función externa,
teoricamente, el valor de x se extingue al finalizar su ejecución.
La funcion interna, como necesita de ese valor de x para su funcionamiento, lo almacena en una zona especial llamada clousure => que es un zona es la cual se almacenan las variables que estuvieron vivas en el pasado
Clousure: "El espacio que se genera en una función cuando esta definida dentro de otra"
Todas las variables que esten definidas dentro de esa zona, pertenecen al clousure de esta función interna
*/

// -----------------------
// Contexto de una función
// -----------------------
/*
Contexto de una función ES una referencia al mismo objeto que contiene esa función => "this"
*/
/*
let window = {
    foo: function() {
        console.log(this);
    }
}
*/
/*
function foo() {
    console.log(this);
}

foo();          //contexto global window
window.foo();   //contexto global window

var persona = {
    nombre: 'Juan',
    saludo: function() {
        console.log(this);
    }
}
persona.saludo(); //cambió el contexto de saludo (esta contenido dentro del objeto persona). No es el contexto global window
*/

/*
el contexto de una función es algo que va cambiando, según el lugar donde se declare. El contexto es dinámico.

Existen múltiples formas de ejecutar una función en JS (para permitir, si se requiere, cambiar el contexto)
    1) Normal
    2) Bind
    3) Call
    4) Apply
    5) new
*/
/*
//1)
function ctx(a,b) {
    console.log(this,a,b);
}

ctx(3,4); // forma normal - window(...)

//4)
ctx.apply({x:1},[5,6]);   //si no le paso parámetros ejecuta en window (...)
                    //si le paso un objeto, va a cambiar el contexto a ese mismo objeto

//3)
ctx.call({x:2},8,9);    //si no le paso parámetros ejecuta en window (...)
                    //si le paso un objeto, va a cambiar el contexto a ese mismo objeto
*/
//El método apply y el método call se diferencian por la manera en la que reciben los parámetros.


// ---------------------------------------------------
// OOP - Funciones constructuras (fábricas de objetos)
// ---------------------------------------------------
/*
var persona = {
    nombre: null,
    edad: null
}

//por referencia (se refieren al mismo objeto 'persona' -> no son independientes)
var juan = persona;
var maria = persona;

var c = [1,2];
var d = c;
c[0] = 11;


//por valor
var a = 'pepe';//true;//5;
var b = a,
a = 'jose';//false;//8;
*/
/*
cómo podemos hacer para que juan y maria sean objetos independientes???
R: Con funciones!
*/
/*
function persona(nombre, edad) {
    var p = {
        nombre : nombre,
        edad: edad
    }
    return p;
}

var juan = persona('Juan', 23);
var maria = persona('María', 22);
*/
/*
en cambia la forma anterior:
var juan = persona;
var maria = persona;

con la de ahora:
var juan = persona('Juan', 23);
var maria = persona('María', 22);

??????

Juan y María en la forma actual, mantienen sus plantillas, o sea, sus datos

Esto se debe a que aplicamos una forma de crear objetos independientes a través un patrón de diseño de JS que se llama "funciones constructoras" ó "Fabrica de objetos"
*/

// ---------------------------------
// Introducción al constructor "new"
// ---------------------------------
/*
El constructor u operador new es similar al creador de instancias de cualquier lenguaje de programación
Como JS se basa en prototipos, new se implementa de manera diferente
*/
/*
function Persona() {
    console.log(this);
}

new Persona;
*/
/*
acá sucede que new va a ejecutar las siguientes acciones
    1) se va a crear un objeto vacio -> var a = {}
    2) se va llamar a la funcion que le sigue a new a través del método call, pasándole como argumento el objeto previamente creado -> Persona.call(a)
    La función Persona se va a EJECUTAR dentro del contexto que se le pasa.
    3) se va a retornar el objeto a
*/
function Persona(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
}

var juan = new Persona('Juan', 33);
var maria = new Persona('María', 29);
