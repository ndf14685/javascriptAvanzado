"use strict"

console.log('Curso JSAv Clase 9');

// -------------------------------------------------------
// Creación de prototipos dentro de funciones contructoras
// -------------------------------------------------------

/*
var a = {} // -> Va a presentar un prototipo, que es de base para todos los objetos

function Persona() {
    //this.x = true;
}
*/
//new Persona(); -> Estamos haciendo una fábrica ó plantilla para todos los objetos que se creen a partir de esta

//En la función constructora aparece una nueva propiedad => "PROTOTYPE"
//Prototype: Es un objeto que se crea cuando nostros creamos nuestra función constructora
/*
podemos usar "prototype" para definir MÁS propiedades DENTRO de mis objetos definidos a través de la función constructora
*/
//CONSTRUCTOR : referencia a la misma función constructora

/*
Persona.prototype.x = true;
let juan = new Persona();
*/


// ----------------------------------------------------------------------
// Diferencia entre las propiedades creadas por instancia a las creados a // través de prototipos
// ----------------------------------------------------------------------
/*
function Persona(nombre) {
    this.nombre = nombre;
}

let ana = new Persona('Ana');
let juan = new Persona('Juan');

ana.apellido = 'Picos';

juan.apellido = 'Gomez';

Persona.prototype.curso = '4B';

ana.edad = 19;
juan.edad = 21;
ana.__proto__.curso = '5B';

console.log(juan.curso);
*/
/*
1) Todo lo que está en el "prototipo" se va a compartir en todoas las instancias
2) Todo lo que está en la "instancia" es particular de cada objeto

El prototito es independiente de la instancia
*/

/*
En prototype se definen los "Métodos" que queremos que compartan todos los objetos
*/
/*
Persona.prototype.saludo = function() {
    console.log('Hola!');
}
*/


// ---------
// HERENCIA
// ---------
/*
Extender el prototipo con un prototipo superior (superfuncion)
*/
/*
function Persona(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
    Superfuncion.call(this); //COMPOSICIÓN DE CLASES
}

Persona.prototype.saludo = function() {
    console.log('Holaaaa!');
}
Persona.prototype = Object.create(Superfuncion.prototype);
*/

/*
//ECMAScript2015 - ES6
class Persona {
    constructor(nombre, edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    saludo() {
        console.log('Holaaa');
    }
}

class Empleado extends Persona {
    constructor(sueldo, nombre, edad) {
        super(nombre, edad);
        this.sueldo = sueldo;
    }
    trabajar() {
        console.log('Trabajando...');
    }
}

let empleado1 = new Empleado(10000, 'Juan', 20);
let empleado2 = new Empleado(11000, 'Ana', 23);
*/

// ---------------------
// COMPOSICIÓN DE CLASES
// ---------------------
/*
function Persona(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
}

Persona.prototype.saludo = function() {
    console.log('Holaaaa!');
}

function Empleado(sueldo,nombre,edad) {
    this.sueldo = sueldo;
    //-------------------------------------
    //herencia de propiedades (composición)
    Persona.call(this,nombre,edad);
    //-------------------------------------
}

//----------------------------------------------------
//herencia de métodos
Empleado.prototype = Object.create(Persona.prototype);
//----------------------------------------------------

Empleado.prototype.calcularSueldo = function() {
    console.log('Calculando...');
}

let empleado1 = new Empleado(12000,'Juan', 27);
let empleado2 = new Empleado(14000,'Ana', 25);
*/

// ------------------------------------
// CONSTRUYENDO HERENCIA CON PROTOTIPOS
// ------------------------------------
//Crear objetos sin pasar por la función constructora
/*
let persona = {
    saludo: function() {
        console.log('hola');
    }
}

let maria = Object.create(persona);
let pedro = Object.create(persona);


//var empleado = {
//    trabajar: function(){
//        console.log('trabajando...');
//    }
//}

//Necesitamos escalonar ambos prototipos para generar herencia
//Como????????

var empleado = Object.create(persona,{
    trabajar: {
        value: function(){
            console.log('trabajando...');
        }
    }
})

let juan = Object.create(empleado);
*/
//-------------------------
// Funciones de class (ES6)
//-------------------------
//Antes de ES6 trabajabamos con funciones contructoras o con prototipos para crear objetos
//Con ES6 eso cambió: ahora tenemos definiciones de clases (class)

//Una definición de clase es una función:

//----------------------------------------------
//Diferencias entre clase y función constructura
//----------------------------------------------
// ----> 1)
/*
class Persona {

}
//DESPUES DE LA DEFINICIÓN DE CLASE
let maria = new Persona();


//ANTES ó DESPUES DE LA DEFINICIÓN DE FUNCIÓN CONTRUCTORA
let juan = new Persona1();

function Persona1() {

}
*/
// ----> 2) En la clase no tenemos paréntesis para pasar los argumentos, se hace a través de la función constructor


// ---------------------------------------
// Métodos de clases 
// ---------------------------------------
//función constructora
/*
function Persona1(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
}

Persona1.prototype.saludo = function() {
    console.log('Holaaaa!');
}

//clases
class Persona {
    constructor(nombre, edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    saludo() {
        console.log('Holaaa');
    }
    static caminar() {
        console.log('Caminando!');
    }
}

let persona1 = new Persona1('Juan', 33);
let persona2 = new Persona('Ana', 26);

Persona1.caminar = function() {
    console.log('Caminando!');
}
*/

//----------------------------------------------
// IIFE
// I: Inmediatly
// I: Invoke
// F: Function
// E: Expression
//----------------------------------------------

/*
function Programa() {
    var privada = true;
}

Programa();
*/

//---------- SOLUCIÓN -> IIFE ----->
/*
(function (numero) {
    console.log(numero);
    var privada = true;
    console.log(privada);
})(33);
*/

// ---------------------------------------------
// MODO ESTRICTO
// ---------------------------------------------
//es un modo que utiliza JS, a traves del cual tenemos que cumplir con ciertas reglas (+ estrictas)

var a = 1

let obj_dinamico = {x:1};
let obj_estatico = Object.create(null,{
    x: {
        value: 1
    }
});

obj_estatico.x = 55;

